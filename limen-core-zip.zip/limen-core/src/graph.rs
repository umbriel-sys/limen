//! Graph contracts, descriptors, and a builder for wiring arbitrary topologies.
//!
//! # Layers
//!
//! - [`Graph`]: executable trait implemented by typed graphs (P0/P1/P2/P2concurrent).
//! - [`descriptor`]: storage-only descriptors (borrowed, owned, and const-buffer).
//! - [`validate`]: descriptor validators (no-alloc port checks; acyclicity with/without `alloc`).
//! - [`builder`] (alloc): ergonomic builder that produces a validated owned descriptor.
//!
//! Runtimes consume the **typed** `Graph` trait; tooling and codegen use descriptors.

use crate::errors::{GraphError, NodeError, NodeErrorKind};
use crate::node::{NodePolicy, StepResult};
use crate::platform::PlatformClock;
use crate::policy::EdgePolicy;
use crate::queue::QueueOccupancy;
use crate::telemetry::Telemetry;

#[cfg(feature = "std")]
use crate::scheduling::NodeSummary;

pub mod descriptor;
pub mod validate;

#[cfg(feature = "alloc")]
pub mod builder;

#[cfg(feature = "alloc")]
pub use descriptor::GraphDescOwned;
pub use descriptor::{
    EdgeDescriptor, GraphDesc, GraphDescBuf, GraphDescriptorView, GraphValidator, NodeDesc,
    NodeKind, PortSchema,
};

#[cfg(feature = "alloc")]
pub use builder::{EdgeHandle, GraphBuilder, InPort, NodeHandle, OutPort};

/// Unified static graph trait for P0/P1/P2 (and P2-concurrent under `std`).
///
/// Your *typed* graph implementations (produced by codegen/assembler) implement
/// this trait. Runtimes call only this API—no topology knowledge required.
pub trait Graph<C: PlatformClock, T: Telemetry> {
    /// Number of nodes and edges (queues) in this typed graph.
    const NODES: usize;

    /// TODO: FILL
    const EDGES: usize;

    /// Init + warmup lifecycle.
    fn initialize(&mut self, _clock: &C, _telemetry: &mut T) -> Result<(), GraphError>;

    /// Start the graph.
    fn start(&mut self, _clock: &C, _telemetry: &mut T) -> Result<(), GraphError>;

    /// Step the node at `index` exactly once.
    fn step_node(
        &mut self,
        index: usize,
        clock: &C,
        telemetry: &mut T,
    ) -> Result<StepResult, NodeError>;

    /// Optional stop hook.
    fn stop(&mut self, _clock: &C, _telemetry: &mut T) -> Result<(), NodeError>;

    /// Per-node policy bundle (for P1/P2 runtime heuristics).
    ///
    /// Default returns a neutral policy; typed graphs may override.
    fn node_policy(&self, _index: usize) -> NodePolicy;

    /// Edge (queue) policy + occupancy surfaces so runtimes can drive backpressure/admission.
    fn edge_policy(&self, edge: usize) -> &EdgePolicy;

    /// TODO: FILL.
    fn edge_occupancy(&self, edge: usize) -> QueueOccupancy;

    /// Convenience: number of edges.
    #[inline]
    fn edge_count(&self) -> usize {
        Self::EDGES
    }

    /// Convenience: number of edges.
    #[inline]
    fn node_count(&self) -> usize {
        Self::NODES
    }

    // ===== P2 scheduler summaries (std only) =====

    /// Provide scheduler summaries (only when `std`).
    /// Implementers should return a slice of length `Self::NODES`.
    #[cfg(feature = "std")]
    fn summaries(&self) -> &[NodeSummary];

    // ===== Optional concurrent stepping API (P2-concurrent). Defaults to unsupported. =====

    /// Whether this graph supports thread-safe stepping of nodes concurrently.
    #[cfg(feature = "std")]
    #[inline]
    fn is_concurrent(&self) -> bool {
        false
    }

    /// Optional concurrent initialize/start (P2-concurrent).
    #[cfg(feature = "std")]
    #[inline]
    fn initialize_and_start_concurrent(&self, _clock: &C, _telemetry: &T) -> Result<(), NodeError> {
        Ok(())
    }

    /// Thread-safe single-step for node `index` (P2-concurrent).
    #[cfg(feature = "std")]
    #[inline]
    fn step_node_threadsafe(
        &self,
        _index: usize,
        _clock: &C,
        _telemetry: &T,
    ) -> Result<StepResult, NodeError> {
        Err(NodeError::new(NodeErrorKind::ExecutionFailed, 0))
    }

    /// Optional concurrent stop (P2-concurrent).
    #[cfg(feature = "std")]
    #[inline]
    fn stop_concurrent(&self, _clock: &C, _telemetry: &T) -> Result<(), NodeError> {
        Ok(())
    }
}
